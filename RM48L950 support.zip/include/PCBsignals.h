/*
 * PCBsignals.h
 *
 *  Created on: Sep 7, 2017
 *      Author: OWNER
 */

#ifndef INCLUDE_PCBSIGNALS_H_
#define INCLUDE_PCBSIGNALS_H_

/* hetPORT1 */
#define Illumination_K18	0	// output U6.2
#define Aiming_Beam_W5		2	// output J10.2
#define Trigger_Pulse_Counter_YSGG_B12	4	// input J11.10
#define DIODE_FAN_V6		5	// output J10.9
// 					NHET1[06]	W3_SCIRX	J21.31	PC_TX0	J7.31	J21.3
#define PATIENT_AIR_B4		12	// output J16.2
//					NHET1[13]	N2_SCITX	J21.29	PC_RX0	J7.29	J21.2
#define PATIENT_WATER_N1	15	// output J16.10
#define	Footswitch_1_A4		16
#define	FRONT_BUTTON_A13	17
#define	Footswitch_2_J1		18
/* hetPORT1 end */

/* SCI/LIN */
//LINTX	B7_SCI2_TX
//LINRX	A7_SCI2_RX
/* SCI/LIN end */
#endif /* INCLUDE_PCBSIGNALS_H_ */
